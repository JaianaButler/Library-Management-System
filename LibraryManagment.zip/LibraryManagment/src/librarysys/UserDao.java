package librarysys;

import java.sql.*;
import javax.swing.JOptionPane;

public class UserDao {
    static String host = "jdbc:derby://localhost:1527/UserDB";
    static String uName = "adminaccess";
    static String uPass = "admin";
    
    public static boolean validate(String user, String password){
        boolean status = false;
        
        try{
            Connection con = DriverManager.getConnection(host, uName, uPass);
            
           String queryString = "SELECT USERNAME, PASSWORD FROM USERS where USERNAME=? and PASSWORD=?";
            PreparedStatement ps = con.prepareStatement(queryString);
            ps.setString(1,user);
            ps.setString(2,password);
            ResultSet results = ps.executeQuery();

            if (results.next()) {
                status = true;
            }else{
                JOptionPane.showMessageDialog(null, "Please Check Username and Password ");
            } 
            results.close();
            con.close();
        }catch(SQLException err){
            System.out.println(err.getMessage());
        }
        
        return status;
    }
    
    public static int save(String firstName, String lastName, String username, String password){
        int status = 0;
        
        try{
            Connection con = DriverManager.getConnection(host, uName, uPass);
            PreparedStatement ps = con.prepareStatement("insert into USERS(FIRST_NAME, LAST_NAME, USERNAME, PASSWORD) values(?,?,?,?)");
            
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, username);
            ps.setString(4, password);
            
            status = ps.executeUpdate();
            
            con.close();
        }catch(SQLException err){
            System.out.println(err.getMessage());
        }
        return status;
    }
}
