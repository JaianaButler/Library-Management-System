package librarysys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DB {
    public static void main(String[] args){
        try{
            String host = "jdbc:derby://localhost:1527/UserDB";
            String uName = "adminaccess";
            String uPass = "admin";
        
            Connection con = DriverManager.getConnection(host, uName, uPass);
        }catch(SQLException err){
            System.out.println(err.getMessage());
        }
    }
}
